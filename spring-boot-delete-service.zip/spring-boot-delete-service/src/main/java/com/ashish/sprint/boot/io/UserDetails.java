package com.ashish.sprint.boot.io;

import java.util.List;

public class UserDetails {
    private List<UserDetail> userDetails;

    public List<UserDetail> getUserDetails() {
        return userDetails;
    }

    public void setUserDetails(List<UserDetail> userDetails) {
        this.userDetails = userDetails;
    }
}
