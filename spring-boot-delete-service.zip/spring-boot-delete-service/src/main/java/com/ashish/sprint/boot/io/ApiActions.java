package com.ashish.sprint.boot.io;

import java.util.List;

public class ApiActions {

    List<ApiAction> apiActions;

    public List<ApiAction> getApiActions() {
        return apiActions;
    }

    public void setApiActions(List<ApiAction> apiActions) {
        this.apiActions = apiActions;
    }
}
