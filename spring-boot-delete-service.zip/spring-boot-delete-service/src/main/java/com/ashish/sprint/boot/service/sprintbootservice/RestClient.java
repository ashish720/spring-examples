package com.ashish.sprint.boot.service.sprintbootservice;

import com.ashish.sprint.boot.exception.UserNotFoundException;
import com.ashish.sprint.boot.io.ApiAction;
import com.ashish.sprint.boot.io.ApiActions;
import com.ashish.sprint.boot.io.UserDetail;
import com.ashish.sprint.boot.io.UserDetails;
import com.ashish.sprint.boot.service.data.DataPropertyHolder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class RestClient {

    @Autowired
    private DataPropertyHolder dataPropertyHolder;

    @RequestMapping(value = "/delete/available/apis",method= RequestMethod.GET)
    public ApiActions fetchAvailableAPIs(){
        List<String> availDeleteActions = Arrays.asList(dataPropertyHolder.getApiLists().split(">"));
        ApiActions apiActions = new ApiActions();
        apiActions.setApiActions(new ArrayList<>());

        availDeleteActions.forEach(availDeleteAction->{
            String[] apiActionData = availDeleteAction.split("-");

            apiActions.getApiActions().add(new ApiAction(apiActionData[0],apiActionData[1],apiActionData[2],apiActionData[3]));
        });
        return apiActions;
    }
    @RequestMapping(value = {"/invoke/delete/single/record","/invoke/delete/multiple/record"},method= RequestMethod.GET)
    public UserDetails invokeDeleteRecords(@RequestParam(value = "ids") String deleteIds) throws IOException, URISyntaxException, UserNotFoundException {
        UserDetails userDetails = new UserDetails();
        userDetails.setUserDetails(new ArrayList<UserDetail>());
        String[] userIds = deleteIds.split(",");
        for(String id:userIds){
            userDetails.getUserDetails().add(new UserDetail(id,"Abhishek","JS"));
        }
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonBody = objectMapper.writeValueAsString(userDetails);
        URI url =null;
        if(userIds.length>0){
            url = new URI("http://localhost:8080/SpringRestV1.0/delete/multiple/records");
        }else{
            url = new URI("http://localhost:8080/SpringRestV1.0/delete/single/record");
        }
        RestTemplate restTemplate = new RestTemplate();
        SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        simpleClientHttpRequestFactory.createRequest(url, HttpMethod.DELETE);
        restTemplate.setRequestFactory(simpleClientHttpRequestFactory);
        // RequestHeaders :: If required you can pass
        /**MultiValueMap<String, String> body = new HttpHeaders();
        body.put("Content-Type",Arrays.asList("application/json".split(",")));
        HttpEntity<String> requestEntity = new HttpEntity<String>(Json.toJson(userDetails),body);**/
        MultiValueMap<String, String> body = new HttpHeaders();
        body.put("Content-Type",Arrays.asList("application/json".split(",")));
        HttpEntity<String> requestEntity = new HttpEntity<String>(jsonBody,body);
        ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, String.class);

        if(result.getStatusCodeValue()!=200){
            throw new UserNotFoundException(String.valueOf(result.getStatusCodeValue()),result.getBody());
        }
        return objectMapper.readValue(result.getBody(),UserDetails.class);
    }
}
