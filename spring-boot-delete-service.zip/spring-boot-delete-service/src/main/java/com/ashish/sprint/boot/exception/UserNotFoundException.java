package com.ashish.sprint.boot.exception;

public class UserNotFoundException extends Exception {

    private String code;
    private String message;

    public UserNotFoundException(String code,String message){
        this.code=code;
        this.message=message;
    }

    @Override
    public String getMessage() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" Exception Catch :: Cause [ ");
        stringBuilder.append("code = "+code);
        stringBuilder.append(", message = "+message+" ]");
        return stringBuilder.toString();
    }
}
