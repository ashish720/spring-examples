package com.ashish.sprint.boot.io;

public class ApiAction {

    private String httpProtocolName;
    private String httpProtocolDescription;
    private String httpApiOperandName;
    private String httpProtocolCallback;

    public ApiAction(String httpProtocolName, String httpProtocolDescription, String httpApiOperandName, String httpProtocolCallback) {
        this.httpProtocolName = httpProtocolName;
        this.httpProtocolDescription = httpProtocolDescription;
        this.httpApiOperandName = httpApiOperandName;
        this.httpProtocolCallback = httpProtocolCallback;
    }

    public String getHttpProtocolName() {
        return httpProtocolName;
    }

    public void setHttpProtocolName(String httpProtocolName) {
        this.httpProtocolName = httpProtocolName;
    }

    public String getHttpProtocolDescription() {
        return httpProtocolDescription;
    }

    public void setHttpProtocolDescription(String httpProtocolDescription) {
        this.httpProtocolDescription = httpProtocolDescription;
    }

    public String getHttpProtocolCallback() {
        return httpProtocolCallback;
    }

    public void setHttpProtocolCallback(String httpProtocolCallback) {
        this.httpProtocolCallback = httpProtocolCallback;
    }

    public String getHttpApiOperandName() {
        return httpApiOperandName;
    }

    public void setHttpApiOperandName(String httpApiOperandName) {
        this.httpApiOperandName = httpApiOperandName;
    }
}
