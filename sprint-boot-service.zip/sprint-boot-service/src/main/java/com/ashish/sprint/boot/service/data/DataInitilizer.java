package com.ashish.sprint.boot.service.data;

import com.ashish.sprint.boot.io.UserDetail;
import com.ashish.sprint.boot.io.UserDetails;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class DataInitilizer {

    public UserDetails prepareUserDatas(String userIds,String userNames,String domains){
        Map<String, UserDetail> data = prepareLocalData(userIds,userNames,domains);
        return populateUserDataMap(data);
    }

    public UserDetails removeUserDatas(String userIds,String userNames,String domains,UserDetails userDetailsIO){
        Map<String, UserDetail> data = prepareLocalData(userIds,userNames,domains);
        for(UserDetail userDetail:userDetailsIO.getUserDetails()){
            if(data.containsKey(userDetail.getId())){
                data.remove(userDetail.getId());
            }
        }
        return populateUserDataMap(data);
    }

    public Map<String, UserDetail> prepareLocalData(String userIds,String userNames,String domains) {
        List<UserDetail> userDetails = createData(userIds,userNames,domains);
        Map<String, UserDetail> data = new HashMap<>();
        for (UserDetail userDetail : userDetails) {
            data.put(userDetail.getId(), userDetail);
        }
        return data;
    }

    public List<UserDetail> createData(String userId,String userName,String domain) {
        List<String> userIds = Arrays.asList(userId.split(","));
        List<String> userNames = Arrays.asList(userName.split(","));
        List<String> domains = Arrays.asList(domain.split(","));
        List<UserDetail> userDetails = new ArrayList<>();
        for (int i = 0; i < userIds.size();i++) {
            userDetails.add(new UserDetail(userIds.get(i),userNames.get(i),domains.get(i)));
        }
        return userDetails;
    }

    public String readPropertyKey(String key, String defaultVal) {
        Properties properties = new Properties();
        try {
            properties.load(this.getClass().getResourceAsStream("com/ashish/spring/boot/properties/data.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return properties.getProperty(key, defaultVal);
    }

    private UserDetails populateUserDataMap(Map<String,UserDetail> dataMap){
        UserDetails userDetails=new UserDetails();
        userDetails.setUserDetails(new ArrayList<>());
        for(Map.Entry<String,UserDetail> userMap:dataMap.entrySet()){
            userDetails.getUserDetails().add(userMap.getValue());
        }
        return userDetails;
    }
}
