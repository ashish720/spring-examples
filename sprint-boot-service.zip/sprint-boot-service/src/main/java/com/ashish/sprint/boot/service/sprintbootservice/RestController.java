package com.ashish.sprint.boot.service.sprintbootservice;

import com.ashish.sprint.boot.service.data.DataInitilizer;
import com.ashish.sprint.boot.service.data.DataPropertyHolder;
import com.ashish.sprint.boot.io.UserDetail;
import com.ashish.sprint.boot.io.UserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.Map;

@org.springframework.web.bind.annotation.RestController
public class RestController {

    @Autowired
    private DataPropertyHolder dataPropertyHolder;
    @Autowired
    private DataInitilizer dataInitilizer;

    @RequestMapping(value = "/delete/single/record",method = RequestMethod.DELETE)
    public UserDetails deleteSingleRecord(@RequestBody UserDetail userDetail){
        UserDetails userDetails=new UserDetails();
        userDetails.setUserDetails(new ArrayList<>());
        userDetails.getUserDetails().add(userDetail);
        return dataInitilizer.removeUserDatas(dataPropertyHolder.getUserIdKeyValue(),dataPropertyHolder.getUserIdKeyValue(),dataPropertyHolder.getDomainKeyValue(),userDetails);
    }

    @RequestMapping(value = "/delete/multiple/records",method = RequestMethod.DELETE)
    public UserDetails deleteMultipleRecord(@RequestBody UserDetails userDetails){
        return dataInitilizer.removeUserDatas(dataPropertyHolder.getUserIdKeyValue(),dataPropertyHolder.getUserIdKeyValue(),dataPropertyHolder.getDomainKeyValue(),userDetails);
    }
    @RequestMapping(value = "/fetch/user/details",method = RequestMethod.GET)
    public UserDetails fetchAllUsers(){
        return dataInitilizer.prepareUserDatas(dataPropertyHolder.getUserIdKeyValue(),dataPropertyHolder.getUserNameKeyValue(),dataPropertyHolder.getDomainKeyValue());
    }
}
