package com.ashish.sprint.boot.service.data;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:properties/data.properties")
public class DataPropertyHolder {
    @Value("${user.ids}")
    private String userIdKeyValue;
    @Value("${user.names}")
    private String userNameKeyValue;
    @Value("${user.domains}")
    private String domainKeyValue;

    public String getUserIdKeyValue() {
        return userIdKeyValue;
    }

    public void setUserIdKeyValue(String userIdKeyValue) {
        this.userIdKeyValue = userIdKeyValue;
    }

    public String getUserNameKeyValue() {
        return userNameKeyValue;
    }

    public void setUserNameKeyValue(String userNameKeyValue) {
        this.userNameKeyValue = userNameKeyValue;
    }

    public String getDomainKeyValue() {
        return domainKeyValue;
    }

    public void setDomainKeyValue(String domainKeyValue) {
        this.domainKeyValue = domainKeyValue;
    }
}
